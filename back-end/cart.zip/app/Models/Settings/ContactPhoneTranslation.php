<?php

namespace App\Models\Settings;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContactPhoneTranslation extends Model
{
    use HasFactory;
    public $timestamps=false;
    protected $guarded=[];

}
